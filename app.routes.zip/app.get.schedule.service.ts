import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class ScheduleService {
  private http = inject(HttpClient);
  
  getSchedule(month:number,year:number) {
    return this.http.get(`http://www.dr-eremeeva.com:8000/schedule/month/${month+1}/year/${year}/`);
  }
}