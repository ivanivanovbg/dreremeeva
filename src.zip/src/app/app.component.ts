import { Component, OnInit, Renderer2, HostListener, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { ScheduleService } from './app.get.schedule.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  @ViewChild('bottomcanvas', { static: true }) bottomcanvas!: ElementRef<HTMLCanvasElement>;
  private ctx!: CanvasRenderingContext2D;

  months_names = ["Януари", "Февруари", "Март", "Април", "Май", "Юни", "Юли", "Август", "Септември", "Октомври", "Ноември", "Декември"];
  title = 'Д-р Еремеева - Педиатричен кабинет - с. Равнец ';
  schedule_date = new Date();
  schedule_month_int: number = this.schedule_date.getMonth();
  schedule_year_int: number = this.schedule_date.getFullYear();
  schedule_month_name: string = this.months_names[this.schedule_month_int];
  schedule_year_string: string = this.schedule_year_int.toString();

  body_bg_color_red: number = 52;
  body_bg_color_green: number = 245;
  body_bg_color_blue: number = 207;

  constructor(private scheduleService: ScheduleService, private renderer: Renderer2) {}

  schedule = Object();

ngOnInit() {
  this.scheduleService.getSchedule(this.schedule_month_int,this.schedule_year_int).subscribe(data => {
    console.log('Schedule data:', data);
    this.schedule = data;
  });

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    this.renderer.setStyle(document.body, "background-color", "#34ebcf");
  }
}

ngAfterViewInit(): void {
  if (typeof window === 'undefined') return; // Prevent SSR error

  const canvas = this.bottomcanvas?.nativeElement;
  if (!canvas) return;

  this.ctx = canvas.getContext('2d')!;
  this.draw();
}


draw() {
  if (!this.ctx) return;
  this.ctx.fillStyle = '#110110';
  this.ctx.beginPath();
  this.ctx.arc(-50, 600, 601, 0, 2 * Math.PI);
  this.ctx.fill();

  this.ctx.fillStyle = '#00CC99';
  this.ctx.beginPath();
  this.ctx.arc(-50, 600, 600, 0, 2 * Math.PI);
  this.ctx.fill();
}

  @HostListener("window:scroll", [])
  onWindowScroll() {
    const scrollY: number = window.scrollY;
    this.alterBackground(scrollY);
  }

  getScheduleParameters() {
    this.schedule_month_int = this.schedule_date.getMonth();
    this.schedule_year_int = this.schedule_date.getFullYear();
    this.schedule_month_name = this.months_names[this.schedule_month_int];
    this.schedule_year_string = this.schedule_year_int.toString();
  }

  alterMonth(num_month: number) {
    this.schedule_date.setMonth(this.schedule_date.getMonth() + num_month);
    this.getScheduleParameters();
    this.scheduleService.getSchedule(this.schedule_month_int,this.schedule_year_int).subscribe(data => {
    console.log('Schedule data:', data);
    this.schedule = data;
    });
  }

  alterBackground(scrollY: number) {
    const max_scroll_offset: number = 800;
    const scroll_ratio: number = Math.min(1, scrollY / max_scroll_offset);
    const temp_green: number = Math.round(this.body_bg_color_green - scroll_ratio * 70);
    const background_color: string = `rgb(${this.body_bg_color_red},${temp_green},${this.body_bg_color_blue})`;
    this.renderer.setStyle(document.body, "background-color", background_color);
  }
}
